#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <time.h>
#include "../src/bank.h"

static double now_ms(void) {
    struct timespec ts; clock_gettime(CLOCK_MONOTONIC, &ts);
    return ts.tv_sec * 1000.0 + ts.tv_nsec / 1e6;
}
typedef struct { bank_t* bank; int n; } bench_arg_t;

static void* worker(void* arg) {
    bench_arg_t* a = (bench_arg_t*)arg;
    unsigned int seed = (unsigned int)(size_t)pthread_self();
    for (int i = 0; i < a->n; i++) {
        int from = rand_r(&seed) % NUM_ACCOUNTS, to = rand_r(&seed) % NUM_ACCOUNTS;
        if (from != to) bank_transfer(a->bank, from, to, 10);
    }
    return NULL;
}

int main(int argc, char** argv) {
    int n_threads = (argc > 1) ? atoi(argv[1]) : 4, n_transfers = 10000;
    bank_t bank; bank_init(&bank, NUM_ACCOUNTS, INITIAL_BALANCE * 100);
    pthread_t threads[64]; bench_arg_t args[64];
    double t0 = now_ms();
    for (int i = 0; i < n_threads; i++) {
        args[i].bank = &bank; args[i].n = n_transfers;
        pthread_create(&threads[i], NULL, worker, &args[i]);
    }
    for (int i = 0; i < n_threads; i++) pthread_join(threads[i], NULL);
    double t1 = now_ms();
    long long expected = (long long)NUM_ACCOUNTS * INITIAL_BALANCE * 100;
    printf("threads=%2d time=%8.2f ms transfers/sec=%10.0f total_ok=%s\n",
           n_threads, t1 - t0,
           (n_threads * n_transfers) / ((t1 - t0) / 1000.0),
           (bank_total(&bank) == expected) ? "YES" : "NO");
    bank_destroy(&bank);
    return 0;
}
