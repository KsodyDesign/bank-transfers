#define _DEFAULT_SOURCE
#include <unistd.h>
#include "bank.h"
int bank_transfer(bank_t* bank, int from, int to, long long amount) {
    if (amount <= 0 || from < 0 || from >= bank->num_accounts || to < 0 || to >= bank->num_accounts) return -1;
    if (from == to) return 0;
    account_t* src = &bank->accounts[from];
    account_t* dst = &bank->accounts[to];
    long long old_src = src->balance;
    long long old_dst = dst->balance;
    if (old_src < amount) return -1;
    usleep(100);
    src->balance = old_src - amount;
    dst->balance = old_dst + amount;
    return 0;
}
