#ifndef BANK_H
#define BANK_H
#include <pthread.h>
#define NUM_ACCOUNTS 10
#define INITIAL_BALANCE 10000LL
#define NUM_THREADS 8
#define TRANSFERS_PER_THREAD 1000
typedef struct { pthread_mutex_t mtx; long long balance; } account_t;
typedef struct { account_t accounts[NUM_ACCOUNTS]; int num_accounts; } bank_t;
int bank_transfer(bank_t* bank, int from, int to, long long amount);
static inline void bank_init(bank_t* b, int n, long long initial) {
    b->num_accounts = n;
    for (int i = 0; i < n; i++) {
        pthread_mutex_init(&b->accounts[i].mtx, NULL);
        b->accounts[i].balance = initial;
    }
}
static inline long long bank_total(const bank_t* b) {
    long long s = 0;
    for (int i = 0; i < b->num_accounts; i++) s += b->accounts[i].balance;
    return s;
}
static inline void bank_destroy(bank_t* b) {
    for (int i = 0; i < b->num_accounts; i++) pthread_mutex_destroy(&b->accounts[i].mtx);
}
#endif
