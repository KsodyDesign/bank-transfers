#include "bank.h"
int bank_transfer(bank_t* bank, int from, int to, long long amount) {
    if (amount <= 0) return -1;
    if (from < 0 || from >= bank->num_accounts) return -1;
    if (to < 0 || to >= bank->num_accounts) return -1;
    if (from == to) return 0;
    int lo = (from < to) ? from : to;
    int hi = (from < to) ? to : from;
    pthread_mutex_lock(&bank->accounts[lo].mtx);
    pthread_mutex_lock(&bank->accounts[hi].mtx);
    account_t* src = &bank->accounts[from];
    account_t* dst = &bank->accounts[to];
    int rc = 0;
    if (src->balance < amount) rc = -1;
    else { src->balance -= amount; dst->balance += amount; }
    pthread_mutex_unlock(&bank->accounts[hi].mtx);
    pthread_mutex_unlock(&bank->accounts[lo].mtx);
    return rc;
}
