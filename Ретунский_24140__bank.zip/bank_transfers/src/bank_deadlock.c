#include <sched.h>
#include "bank.h"
int bank_transfer(bank_t* bank, int from, int to, long long amount) {
    account_t* src = &bank->accounts[from];
    account_t* dst = &bank->accounts[to];
    pthread_mutex_lock(&src->mtx);
    sched_yield();
    pthread_mutex_lock(&dst->mtx);
    int rc = 0;
    if (src->balance < amount) rc = -1;
    else { src->balance -= amount; dst->balance += amount; }
    pthread_mutex_unlock(&dst->mtx);
    pthread_mutex_unlock(&src->mtx);
    return rc;
}
