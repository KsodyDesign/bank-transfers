#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <pthread.h>
#include "../src/bank.h"

static int fails = 0;
#define CHECK(cond, msg) do { if (cond) printf("  [OK]   %s\n", msg); \
    else { printf("  [FAIL] %s\n", msg); fails++; } } while (0)

typedef struct { bank_t* b; int n; unsigned s; } arg_t;
static unsigned lcg_rand(unsigned* s) { *s = *s * 1103515245u + 12345u; return (*s >> 16) & 0x7fff; }

static void* client_thread(void* p) {
    arg_t* a = p;
    for (int i = 0; i < a->n; i++) {
        int f = lcg_rand(&a->s) % NUM_ACCOUNTS, t = lcg_rand(&a->s) % NUM_ACCOUNTS;
        bank_transfer(a->b, f, t, 1 + lcg_rand(&a->s) % 100);
    }
    return NULL;
}

static void run_threads(bank_t* b, int th, int n) {
    pthread_t T[64]; arg_t A[64];
    for (int i = 0; i < th; i++) {
        A[i] = (arg_t){ b, n, 1u + i * 7919u };
        pthread_create(&T[i], NULL, client_thread, &A[i]);
    }
    for (int i = 0; i < th; i++) pthread_join(T[i], NULL);
}

static void check_sum(bank_t* b, const char* name) {
    long long exp = (long long)NUM_ACCOUNTS * INITIAL_BALANCE, tot = bank_total(b);
    printf("  total=%lld expected=%lld разница: %lld\n", tot, exp, tot - exp);
    CHECK(tot == exp, name);
}

static void t1(void) { printf("T1 инициализация\n"); bank_t b; bank_init(&b, NUM_ACCOUNTS, INITIAL_BALANCE); check_sum(&b, "T1 сумма"); bank_destroy(&b); }
static void t2(void) {
    printf("T2 один перевод\n"); bank_t b; bank_init(&b, NUM_ACCOUNTS, INITIAL_BALANCE);
    int rc = bank_transfer(&b, 0, 1, 100);
    CHECK(rc == 0 && b.accounts[0].balance == INITIAL_BALANCE - 100 && b.accounts[1].balance == INITIAL_BALANCE + 100, "T2 A-100, B+100");
    check_sum(&b, "T2 сумма"); bank_destroy(&b);
}
static void t3(void) {
    printf("T3 1000 переводов, 1 поток\n"); bank_t b; bank_init(&b, NUM_ACCOUNTS, INITIAL_BALANCE);
    int ok = 0; for (int i = 0; i < 1000; i++) if (bank_transfer(&b, 0, 1, 5) == 0) ok++;
    CHECK(ok == 1000, "T3 1000 успешных"); check_sum(&b, "T3 сумма"); bank_destroy(&b);
}
static void t4(void) {
    printf("T4 8 потоков x 1000\n"); bank_t b; bank_init(&b, NUM_ACCOUNTS, INITIAL_BALANCE);
    run_threads(&b, NUM_THREADS, TRANSFERS_PER_THREAD); check_sum(&b, "T4 сумма"); bank_destroy(&b);
}
static void t5(void) {
    printf("T5 недостаточно средств\n"); bank_t b; bank_init(&b, 2, 100);
    int rc = bank_transfer(&b, 0, 1, 200);
    CHECK(rc == -1 && b.accounts[0].balance == 100 && b.accounts[1].balance == 100, "T5 rc=-1, балансы целы"); bank_destroy(&b);
}
static void t6(void) {
    printf("T6 перевод самому себе\n"); bank_t b; bank_init(&b, NUM_ACCOUNTS, INITIAL_BALANCE);
    int rc = bank_transfer(&b, 3, 3, 50);
    CHECK(rc == 0 && b.accounts[3].balance == INITIAL_BALANCE, "T6 rc=0, баланс не изменился"); bank_destroy(&b);
}
static void t7(void) {
    printf("T7 стресс 16 x 10000\n"); bank_t b; bank_init(&b, NUM_ACCOUNTS, INITIAL_BALANCE);
    time_t t0 = time(NULL); run_threads(&b, 16, 10000);
    check_sum(&b, "T7 сумма"); CHECK(time(NULL) - t0 < 30, "T7 время < 30 c"); bank_destroy(&b);
}

int main(void) {
    t1(); t2(); t3(); t4(); t5(); t6(); t7();
    if (fails) { printf("=== FAILED: %d ===\n", fails); return 1; }
    printf("=== ALL TESTS PASSED ===\n"); return 0;
}
